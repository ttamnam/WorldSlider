var express = require("express");
var app = express();
var request = require("request")
app.set("view engine", "ejs")

app.get("/results", function(req, res){
	res.render("search")
});

app.get("/", function(req, res){
	
	request('https://www.reddit.com/r/earthporn.api', function (error, response, body){
		if(!error && response.statusCode == 200) {
			var data = JSON.parse(body)
			const NumArr = []
			for (i = 0; i < 5; i++){
				num = Math.floor(Math.random() * data["data"]["children"].length)
				NumArr.push(num)
			}
			res.render("fullscreen", {data: data, NumArr: NumArr});
			console.log(data["data"]["children"][NumArr[0]]["data"]["url"])
			console.log(NumArr)
		}	
	});
});

app.listen(3000, function(){
	console.log("Server has started!!!");
});